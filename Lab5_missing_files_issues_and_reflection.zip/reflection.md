# Reflection: Static Code Analysis

## 1. What is static code analysis, and why is it useful?

Static code analysis examines source code without needing to execute the program. It helps identify potential defects, security concerns, and style problems early in development. This makes code easier to review and maintain and can reduce the chance that avoidable issues reach users.

## 2. How do Pylint, Bandit, and Flake8 differ?

Pylint focuses on code quality, possible errors, naming, and maintainability. Bandit checks Python code for common security-related patterns. Flake8 focuses mainly on style and formatting rules, including PEP 8 conventions. Using all three provides complementary checks rather than relying on a single tool.

## 3. What changed after fixing the reported issues?

The updated script was checked again with all three tools. The final local checks reported a Pylint score of 10.00/10, no issues identified by Bandit, and no Flake8 output. The script was also run successfully. These results suggest that the changes improved code quality and formatting while retaining the program's basic behaviour.

## 4. What are the limitations of static analysis, and what did you learn?

Static analysis can flag patterns that need human review, and it cannot prove that a program is correct in every situation. It should be combined with running the program, testing expected behaviour, and reviewing the changes. This exercise showed that different tools detect different classes of issues and that rerunning them after changes helps verify the cleanup.

---

**Important:** The supplied lab handout requests reflection answers but the extracted handout text available here does not show the exact reflection-question wording. These are draft responses aligned with the lab's stated learning outcomes; adjust them if your instructor provided separate questions.
