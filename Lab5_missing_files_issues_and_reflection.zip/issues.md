# Static Analysis Issue Log

**Program:** `wildlife_sightings.py`  
**Tools used:** Pylint, Bandit, Flake8

> Note: Match the descriptions below against the saved `*_report_before.txt` files before final submission. The original report contents were not available in this chat, so exact message IDs and line numbers are intentionally not guessed.

| Issue | Type / tool | Line(s) | Description | Fix approach / verification |
|---|---|---:|---|---|
| Code-quality findings reported by Pylint | Code quality | See `pylint_report_before.txt` | Pylint identifies maintainability and correctness concerns in the original script. | Update the relevant code based on the original Pylint messages. The final report should show a score above 9.5/10; the local run previously reported 10.00/10. |
| Security-pattern findings reported by Bandit | Security | See `bandit_report_before.txt` | Bandit checks for common Python security issues and unsafe patterns. | Address the specific findings in the original Bandit report and rerun Bandit. The final local run reported no issues identified. |
| PEP 8/style violations reported by Flake8 | Style / formatting | See `flake8_report_before.txt` | Flake8 checks formatting, whitespace, line length and related style problems. | Correct the reported formatting issues and rerun Flake8. The final local run produced no output, indicating no reported violations. |
| Program structure/readability improvements | Maintainability | See code diff | The original implementation required cleanup to make the script easier to read and maintain. | Review the code changes between `wildlife_sightings_before.py` and `wildlife_sightings.py`; keep only changes that are supported by the original reports and code diff. |

## Verification summary

- The cleaned script was run successfully and printed a sighting record.
- Pylint's final score was reported locally as **10.00/10**.
- Bandit reported **no issues identified** in the final run.
- Flake8 produced **no output** in the final run.

Before submission, replace the general entries above with at least four *specific* findings from the before reports, including their actual message codes and line numbers. Do not claim an issue was fixed unless the code diff supports it.
